SECRET_KEY = 'development key'
MAX_CONTENT_LENGTH = 3 * 1024 * 1024
POSTS_PER_PAGE = 10
UPLOAD_FOLDER = 'static/Uploads/'
EMAIL_FOLDER = 'static/email/'
DEFAULT_IMAGE_FOLDER = 'static/default/img/'
DEFAULT_IMAGE_COUNT = 10
