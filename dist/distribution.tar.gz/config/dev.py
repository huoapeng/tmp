SQLALCHEMY_DATABASE_URI = 'mysql://root:@localhost/mydatabase?charset=utf8'
DEBUG = True
SQLALCHEMY_TRACK_MODIFICATIONS = True
ROOT_PATH = '/Users/huoapeng/myproject/REST/'
IP_ADDRESS = '127.0.0.1:5000'
# SERVER_NAME = '127.0.0.1:5000'