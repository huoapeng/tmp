SQLALCHEMY_DATABASE_URI = 'mysql://root:@localhost/mydatabase'
DEBUG = False
SQLALCHEMY_TRACK_MODIFICATIONS = False
ROOT_PATH = '/usr/share/nginx/html/'
IP_ADDRESS = '10.0.1.122:8080'