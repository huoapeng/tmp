# SQLALCHEMY_DATABASE_URI = 'mysql://juxing:hiPpo111111@rm-uf6o082066v59n9sv.mysql.rds.aliyuncs.com:3306/hippo'
SQLALCHEMY_DATABASE_URI = 'mysql://root:@localhost/mydatabase'
DEBUG = False
SQLALCHEMY_TRACK_MODIFICATIONS = False
ROOT_PATH = '/usr/share/nginx/html/'
IP_ADDRESS = '101.37.33.55:8080'
# SERVER_NAME = '139.196.183.6'